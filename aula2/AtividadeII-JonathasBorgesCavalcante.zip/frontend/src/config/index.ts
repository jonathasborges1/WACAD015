const config = {
   // API_URL: 'https://ecb9-200-129-163-72.ngrok-free.app',
   API_URL: 'http://10.208.4.27:3333',
}

export { config }